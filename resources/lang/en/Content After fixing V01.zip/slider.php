<?php 
return [
  'title' => 'Title' ,   
  'title_ar' => 'Arabic Title' ,   
  'details' => 'Details' ,   
  'details_ar' => 'Arabic Datails' ,   
  'link' => 'link' ,   
  'photo' => 'Photo',
    "sliders" => "Sliders",
];