@extends('layouts.app')
@section('title', 'shipment')

@section('content')

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>@lang( 'sale.Shipping company' )
      
    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
    </ol> -->
</section>

<!-- Main content -->
<section class="content">
    @component('components.widget', ['class' => 'box-primary', 'title' => __( 'sale.all_Shipping company' )])
        @can('sell.view')
            @slot('tool')
                <div class="box-tools">
                    <button type="button" class="btn btn-block btn-primary btn-modal" 
                        data-href="{{action('Admin\ShipmentController@create')}}" 
                        data-container=".campaigns_modal">
                        <i class="fa fa-plus"></i> @lang( 'messages.add' )</button>
                </div>
            @endslot
        @endcan
        @can('sell.view')
        <div class="row">
            @foreach ($brands as $customer)
            <div class="col-lg-4 mb-4">
                <div class="ship-cad-box">
                    <img src="https://dotcomaramexprod.blob.core.windows.net/default/images/default-source/press-releases/aramex-s-revenue-increased-by-19--to-aed-1-507-million-in-q3-202077d47d88b3f2659d9310ff0100e7fe0c.png">
                    <div class="d-flex justify-content-between py-3">
                        <h3>{{ $customer->name }}</h3>
                        <h3>{{ $customer->name_ar }}</h3>    
                    </div>
                    <p>{{ $customer->phone }}</p>
                    <hr class="py-3">
                    <div class='ship-card-icons d-flex justify-content-between'>
                        
                           @can("sell.update")
                            <button data-href="{{action('Admin\ShipmentController@edit', [$customer->id])}}" class="btn btn-xs btn-primary edit_campaigns_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                                &nbsp;
                            @endcan
                            @can("sell.delete")
                                <a href="{{action('Admin\ShipmentController@destroy', [$customer->id])}}" class="btn btn-xs btn-danger delete_campaigns_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</a>
                            @endcan 
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        @endcan
        
        @can('sell.view')
            <div class="table-responsive">
                <table class="table table-bordered table-striped" id="trafic_table">
                    <thead>
                        <tr>
                            <th>@lang( 'sale.name' )</th>
                            <th>@lang( 'sale.name_ar' )</th>
                           
                            <th>@lang( 'sale.phone' )</th>
                         
                            <th>@lang( 'messages.action' )</th>
                        </tr>
                    </thead>
                    <tbody>
                             @foreach ($brands as $customer)
                                <tr>
                                    <td>{{ $customer->name }}</td>
                                    <td>{{ $customer->name_ar }}</td>
                                  
                                    <td>{{ $customer->phone }}</td>
                          
                              
                                    <td>
                                       @can("sell.update")
                                        <button data-href="{{action('Admin\ShipmentController@edit', [$customer->id])}}" class="btn btn-xs btn-primary edit_campaigns_button"><i class="glyphicon glyphicon-edit"></i> @lang("messages.edit")</button>
                                            &nbsp;
                                        @endcan
                                        @can("sell.delete")
                                            <a href="{{action('Admin\ShipmentController@destroy', [$customer->id])}}" class="btn btn-xs btn-danger delete_campaigns_button"><i class="glyphicon glyphicon-trash"></i> @lang("messages.delete")</a>
                                        @endcan  
                                    </td>
                                </tr>
                            @endforeach
                            
                            
                            
                            </tbody>
                </table>
            </div>
        @endcan
    @endcomponent

    <div class="modal fade campaigns_modal" tabindex="-1" role="dialog" 
    	aria-labelledby="gridSystemModalLabel">
    </div>

</section>
<!-- /.content -->

@endsection
@section('javascript')
    <script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready( function () {
            $('#trafic_table').DataTable();
        });
    </script>
@endsection